package com.technoclient;

import com.technoclient.config.ConfigManager;
import com.technoclient.hud.HUDOverlay;
import com.technoclient.keybind.KeybindManager;
import com.technoclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TechnoClient implements ClientModInitializer {
    public static final String MOD_ID = "technoclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static TechnoClient instance;

    private ModuleManager moduleManager;
    private KeybindManager keybindManager;
    private ConfigManager configManager;

    @Override
    public void onInitializeClient() {
        instance = this;
        LOGGER.info("Initializing Techno Client for Fabric 1.21...");

        this.moduleManager = new ModuleManager();
        this.configManager = new ConfigManager();
        this.keybindManager = new KeybindManager();

        this.moduleManager.init();
        this.configManager.load();
        this.keybindManager.init();

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            HUDOverlay.render(drawContext, tickCounter);
        });

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            if (configManager != null) {
                configManager.save();
            }
        }));
    }

    public static TechnoClient getInstance() {
        return instance;
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public KeybindManager getKeybindManager() {
        return keybindManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }
}
