package com.technoclient.gui;

import com.technoclient.TechnoClient;
import com.technoclient.module.Category;
import com.technoclient.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class ClientMenuScreen extends Screen {
    private Category selectedCategory = Category.COMBAT;
    private String searchQuery = "";

    public ClientMenuScreen() {
        super(Text.literal("Techno Client Menu"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        int leftPanelWidth = 120;
        int topBarHeight = 40;

        context.fill(30, topBarHeight, this.width - 30, this.height - 30, 0xE0121212);
        context.fill(30, topBarHeight, 30 + leftPanelWidth, this.height - 30, 0xFFA0A0A);
        context.drawText(this.textRenderer, "TECHNO CLIENT", 40, topBarHeight + 15, 0x00FF88, true);

        int catY = topBarHeight + 50;
        for (Category category : Category.values()) {
            boolean isSelected = (category == selectedCategory);
            int color = isSelected ? 0x00FF88 : 0xAAAAAA;

            if (mouseX >= 35 && mouseX <= 30 + leftPanelWidth && mouseY >= catY - 2 && mouseY <= catY + 12) {
                color = 0xFFFFFF;
            }

            context.drawText(this.textRenderer, category.getName(), 45, catY, color, false);
            catY += 22;
        }

        int moduleX = 30 + leftPanelWidth + 20;
        int moduleY = topBarHeight + 20;
        List<Module> modules = TechnoClient.getInstance().getModuleManager().getModulesByCategory(selectedCategory);

        for (Module module : modules) {
            int cardWidth = this.width - moduleX - 50;
            int cardHeight = 35;

            context.fill(moduleX, moduleY, moduleX + cardWidth, moduleY + cardHeight, 0xFF1E1E1E);
            context.drawText(this.textRenderer, module.getName(), moduleX + 10, moduleY + 6, 0xFFFFFF, false);
            context.drawText(this.textRenderer, module.getDescription(), moduleX + 10, moduleY + 18, 0x888888, false);

            int btnWidth = 40;
            int btnHeight = 16;
            int btnX = moduleX + cardWidth - btnWidth - 10;
            int btnY = moduleY + 9;
            int btnColor = module.isEnabled() ? 0xFF00FF88 : 0xFF444444;

            context.fill(btnX, btnY, btnX + btnWidth, btnY + btnHeight, btnColor);
            String toggleText = module.isEnabled() ? "ON" : "OFF";
            context.drawText(this.textRenderer, toggleText, btnX + 12, btnY + 4, 0xFF000000, false);

            moduleY += cardHeight + 10;
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int leftPanelWidth = 120;
        int topBarHeight = 40;

        int catY = topBarHeight + 50;
        for (Category category : Category.values()) {
            if (mouseX >= 35 && mouseX <= 30 + leftPanelWidth && mouseY >= catY - 2 && mouseY <= catY + 12) {
                this.selectedCategory = category;
                return true;
            }
            catY += 22;
        }

        int moduleX = 30 + leftPanelWidth + 20;
        int moduleY = topBarHeight + 20;
        List<Module> modules = TechnoClient.getInstance().getModuleManager().getModulesByCategory(selectedCategory);

        for (Module module : modules) {
            int cardWidth = this.width - moduleX - 50;
            int cardHeight = 35;
            int btnWidth = 40;
            int btnHeight = 16;
            int btnX = moduleX + cardWidth - btnWidth - 10;
            int btnY = moduleY + 9;

            if (mouseX >= btnX && mouseX <= btnX + btnWidth && mouseY >= btnY && mouseY <= btnY + btnHeight) {
                module.toggle();
                TechnoClient.getInstance().getConfigManager().save();
                return true;
            }
            moduleY += cardHeight + 10;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
