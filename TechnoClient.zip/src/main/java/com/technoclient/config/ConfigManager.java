package com.technoclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.technoclient.TechnoClient;
import com.technoclient.module.Module;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Path;

public class ConfigManager {
    private final File configFile;
    private final Gson gson;

    public ConfigManager() {
        Path configDir = FabricLoader.getInstance().getConfigDir();
        this.configFile = configDir.resolve("technoclient.json").toFile();
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }

    public void save() {
        try {
            JsonObject root = new JsonObject();
            JsonObject modulesObj = new JsonObject();

            for (Module m : TechnoClient.getInstance().getModuleManager().getModules()) {
                JsonObject mData = new JsonObject();
                mData.addProperty("enabled", m.isEnabled());
                mData.addProperty("keybind", m.getKeyBind());
                modulesObj.add(m.getName(), mData);
            }

            root.add("modules", modulesObj);

            try (FileWriter writer = new FileWriter(configFile)) {
                gson.toJson(root, writer);
            }
        } catch (Exception e) {
            TechnoClient.LOGGER.error("Failed to save Techno Client config", e);
        }
    }

    public void load() {
        if (!configFile.exists()) return;

        try (FileReader reader = new FileReader(configFile)) {
            JsonObject root = gson.fromJson(reader, JsonObject.class);
            if (root != null && root.has("modules")) {
                JsonObject modulesObj = root.getAsJsonObject("modules");
                for (Module m : TechnoClient.getInstance().getModuleManager().getModules()) {
                    if (modulesObj.has(m.getName())) {
                        JsonObject mData = modulesObj.getAsJsonObject(m.getName());
                        if (mData.has("enabled")) m.setEnabled(mData.get("enabled").getAsBoolean());
                        if (mData.has("keybind")) m.setKeyBind(mData.get("keybind").getAsInt());
                    }
                }
            }
        } catch (Exception e) {
            TechnoClient.LOGGER.error("Failed to load Techno Client config", e);
        }
    }
}
