package com.technoclient.keybind;

import com.technoclient.TechnoClient;
import com.technoclient.gui.ClientMenuScreen;
import com.technoclient.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KeybindManager {
    private KeyBinding menuKey;

    public void init() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.technoclient.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_SHIFT,
                "category.technoclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new ClientMenuScreen());
            }

            if (client.player != null) {
                for (Module module : TechnoClient.getInstance().getModuleManager().getModules()) {
                    module.onTick();
                }
            }
        });
    }
}
