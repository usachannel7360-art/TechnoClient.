package com.technoclient.hud;

import com.technoclient.TechnoClient;
import com.technoclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class HUDOverlay {
    public static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden) return;

        Module fpsMod = TechnoClient.getInstance().getModuleManager().getModuleByName("FPS Counter");
        if (fpsMod != null && fpsMod.isEnabled()) {
            int fps = client.getCurrentFps();
            String text = "FPS: " + fps;
            context.drawText(client.textRenderer, text, 10, 10, 0x00FF88, true);
        }
    }
}
