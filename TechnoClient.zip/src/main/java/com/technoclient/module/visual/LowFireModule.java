package com.technoclient.module.visual;

import com.technoclient.module.Category;
import com.technoclient.module.Module;
import org.lwjgl.glfw.GLFW;

public class LowFireModule extends Module {
    public LowFireModule() {
        super("Low Fire", "Lowers screen-space fire rendering for high combat visibility.", Category.VISUAL, GLFW.GLFW_KEY_UNKNOWN);
    }
}
