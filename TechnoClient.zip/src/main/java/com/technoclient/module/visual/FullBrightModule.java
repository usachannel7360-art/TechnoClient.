package com.technoclient.module.visual;

import com.technoclient.module.Category;
import com.technoclient.module.Module;
import org.lwjgl.glfw.GLFW;

public class FullBrightModule extends Module {
    public FullBrightModule() {
        super("Full Bright", "Maximizes brightness for visibility in dark areas.", Category.VISUAL, GLFW.GLFW_KEY_B);
    }
}
