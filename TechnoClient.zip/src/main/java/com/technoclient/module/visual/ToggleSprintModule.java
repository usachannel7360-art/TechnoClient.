package com.technoclient.module.visual;

import com.technoclient.module.Category;
import com.technoclient.module.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class ToggleSprintModule extends Module {
    public ToggleSprintModule() {
        super("Toggle Sprint", "Automatically maintains sprint status.", Category.VISUAL, GLFW.GLFW_KEY_G);
    }

    @Override
    public void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (this.isEnabled() && client.player != null && client.options.forwardKey.isPressed()) {
            client.player.setSprinting(true);
        }
    }
}
