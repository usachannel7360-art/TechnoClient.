package com.technoclient.module.performance;

import com.technoclient.module.Category;
import com.technoclient.module.Module;
import org.lwjgl.glfw.GLFW;

public class FpsCounterModule extends Module {
    public FpsCounterModule() {
        super("FPS Counter", "Renders current FPS on the HUD.", Category.HUD, GLFW.GLFW_KEY_UNKNOWN);
        setEnabled(true);
    }
}
