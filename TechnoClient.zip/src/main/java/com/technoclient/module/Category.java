package com.technoclient.module;

public enum Category {
    COMBAT("Combat"),
    PVP("PvP"),
    VISUAL("Visual"),
    PERFORMANCE("Performance"),
    HUD("HUD"),
    WORLD("World"),
    GENERAL("General");

    private final String name;

    Category(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
