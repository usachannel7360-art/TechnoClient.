package com.technoclient.module;

import com.technoclient.module.visual.FullBrightModule;
import com.technoclient.module.visual.LowFireModule;
import com.technoclient.module.visual.ToggleSprintModule;
import com.technoclient.module.performance.FpsCounterModule;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        // Visual
        register(new FullBrightModule());
        register(new LowFireModule());
        register(new ToggleSprintModule());

        // Performance / HUD
        register(new FpsCounterModule());
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getModulesByCategory(Category category) {
        return modules.stream()
                .filter(m -> m.getCategory() == category)
                .collect(Collectors.toList());
    }

    public Module getModuleByName(String name) {
        return modules.stream()
                .filter(m -> m.getName().equalsIgnoreCase(name))
                .findFirst()
                .orElse(null);
    }
}
