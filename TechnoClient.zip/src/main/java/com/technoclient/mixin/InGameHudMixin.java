package com.technoclient.mixin;

import com.technoclient.TechnoClient;
import com.technoclient.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true)
    private void onRenderOverlay(DrawContext context, net.minecraft.util.Identifier texture, float opacity, CallbackInfo ci) {
        if (texture.getPath().contains("fire")) {
            Module lowFire = TechnoClient.getInstance().getModuleManager().getModuleByName("Low Fire");
            if (lowFire != null && lowFire.isEnabled()) {
                ci.cancel(); // Clears full-screen fire clutter
            }
        }
    }
}
