package com.technoclient.mixin;

import com.technoclient.TechnoClient;
import com.technoclient.module.Module;
import net.minecraft.client.render.LightmapTextureManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(LightmapTextureManager.class)
public class LightmapTextureManagerMixin {
    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/texture/NativeImage;setColor(III)V"))
    private void overrideLightmapColor(Args args) {
        Module fullbright = TechnoClient.getInstance().getModuleManager().getModuleByName("Full Bright");
        if (fullbright != null && fullbright.isEnabled()) {
            args.set(2, 0xFFFFFFFF); // Full luminance
        }
    }
}
