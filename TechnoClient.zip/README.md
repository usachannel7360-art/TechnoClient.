# Techno Client (Fabric 1.21.1)

Techno Client is a lightweight, customizable PvP/SMP client designed for Minecraft Java Edition (Fabric Loader) with primary optimization for Android launcher environments like Mojo Launcher and PojavLauncher, while remaining fully compatible with desktop launcher environments.

## Features
- Custom Client Menu GUI (Default Key: **LEFT SHIFT**)
- Category Navigation & Module Management
- Persistent Config Storage (`config/technoclient.json`)
- Modules: Full Bright, Low Fire, Toggle Sprint, FPS Counter
- Touchscreen and Mouse friendly layout

## Building from Source

### Requirements
- JDK 21 or higher
- Internet connection (for Gradle dependency downloads)

### Command
```bash
./gradlew build
```
The output JAR file will be located at:
`build/libs/TechnoClient-1.0.0.jar`

## Installation
Place the compiled `.jar` file into your `.minecraft/mods` directory (or `/sdcard/MojoLauncher/.minecraft/mods/` on Mojo Launcher). Ensure Fabric Loader 0.16.0+ and Fabric API for 1.21.1 are installed.
